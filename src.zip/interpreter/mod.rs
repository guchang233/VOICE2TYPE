pub mod chunker;
pub mod loopback;
pub mod pipeline;
pub mod subtitle_window;

use std::sync::atomic::{AtomicBool, AtomicU8, Ordering};
use std::sync::Arc;

use crate::config::ConfigManager;
use crate::utils::logger::{write_log, write_log_line, LogLevel};
use chunker::AudioChunker;
use subtitle_window::SubtitleWindow;

pub static AUDIO_SOURCE: AtomicU8 = AtomicU8::new(0);

pub struct InterpreterEngine {
    stop_flag: Arc<AtomicBool>,
    pub subtitle_window: SubtitleWindow,
    capture_handle: Option<std::thread::JoinHandle<()>>,
    chunker_handle: Option<std::thread::JoinHandle<()>>,
    pipeline_handle: Option<std::thread::JoinHandle<()>>,
}

impl InterpreterEngine {
    pub fn start(config: Arc<ConfigManager>) -> Result<Self, String> {
        let stop_flag = Arc::new(AtomicBool::new(false));

        let audio_source_val = if config.interpreter_audio_source() == "microphone" {
            loopback::AUDIO_SOURCE_MICROPHONE
        } else {
            loopback::AUDIO_SOURCE_SPEAKER
        };
        AUDIO_SOURCE.store(audio_source_val, Ordering::SeqCst);

        let audio_source = Arc::new(AtomicU8::new(audio_source_val));

        let subtitle_window = SubtitleWindow::new(
            config.interpreter_subtitle_click_through(),
            config.interpreter_subtitle_opacity(),
            config.interpreter_subtitle_position(),
            config.interpreter_subtitle_font_size(),
        );

        subtitle_window.set_original_font_size(config.interpreter_original_font_size());
        subtitle_window.set_original_color(config.interpreter_original_color());
        subtitle_window.set_translated_font_size(config.interpreter_translated_font_size());
        subtitle_window.set_translated_color(config.interpreter_translated_color());

        write_log_line("[字幕] 正在初始化实时字幕引擎...", None);

        let (audio_tx, audio_rx): (std::sync::mpsc::Sender<f32>, std::sync::mpsc::Receiver<f32>) =
            std::sync::mpsc::channel();

        let (sample_rate_tx, sample_rate_rx) = std::sync::mpsc::channel::<u32>();
        let (error_tx, error_rx) = std::sync::mpsc::channel::<String>();

        let capture_stop = stop_flag.clone();
        let capture_audio_source = audio_source.clone();
        let capture_handle = loopback::start_loopback_capture(
            capture_stop,
            capture_audio_source,
            audio_tx,
            sample_rate_tx,
            error_tx,
        );

        let sample_rate = match sample_rate_rx.recv_timeout(std::time::Duration::from_secs(5)) {
            Ok(rate) => rate,
            Err(_) => {
                stop_flag.store(true, Ordering::Relaxed);
                let _ = capture_handle.join();
                write_log(LogLevel::ERROR, "[字幕] 音频捕获初始化超时", None);
                return Err("音频捕获初始化超时".to_string());
            }
        };

        write_log(LogLevel::INFO, &format!("[字幕] 获取采样率: {}", sample_rate), None);

        if let Ok(err) = error_rx.try_recv() {
            stop_flag.store(true, Ordering::Relaxed);
            let _ = capture_handle.join();
            write_log(LogLevel::ERROR, &format!("[字幕] 音频捕获错误: {}", err), None);
            return Err(format!("音频捕获失败: {}", err));
        }

        let chunk_ms = config.interpreter_chunk_ms();
        let chunker_stop = stop_flag.clone();
        let (chunk_tx, chunk_rx): (
            std::sync::mpsc::Sender<Vec<u8>>,
            std::sync::mpsc::Receiver<Vec<u8>>,
        ) = std::sync::mpsc::channel();

        let chunker_handle = std::thread::spawn(move || {
            let mut sample_rate = sample_rate;
            let mut chunker = AudioChunker::new(sample_rate, chunk_ms);
            loop {
                if chunker_stop.load(Ordering::Relaxed) {
                    chunker.force_flush(&chunk_tx);
                    break;
                }

                let new_rate = loopback::CURRENT_SAMPLE_RATE.load(Ordering::SeqCst);
                if new_rate > 0 && new_rate != sample_rate {
                    chunker.force_flush(&chunk_tx);
                    sample_rate = new_rate;
                    chunker = AudioChunker::new(sample_rate, chunk_ms);
                    write_log(LogLevel::INFO, &format!("[字幕] 采样率更新: {}Hz", sample_rate), None);
                }

                match audio_rx.recv_timeout(std::time::Duration::from_millis(100)) {
                    Ok(sample) => {
                        chunker.push_sample(sample, &chunk_tx);
                    }
                    Err(std::sync::mpsc::RecvTimeoutError::Timeout) => {
                        chunker.flush_if_stale(&chunk_tx);
                    }
                    Err(std::sync::mpsc::RecvTimeoutError::Disconnected) => {
                        chunker.force_flush(&chunk_tx);
                        break;
                    }
                }
            }
        });

        write_log_line("[字幕] 音频分块线程已启动", None);

        let pipeline_stop = stop_flag.clone();
        let pipeline_config = config.clone();
        let subtitle = subtitle_window.clone();

        let pipeline_handle = std::thread::spawn(move || {
            let rt = tokio::runtime::Builder::new_current_thread()
                .enable_all()
                .build()
                .unwrap();

            rt.block_on(async move {
                loop {
                    if pipeline_stop.load(Ordering::Relaxed) {
                        break;
                    }

                    match chunk_rx.recv_timeout(std::time::Duration::from_millis(100)) {
                        Ok(wav_data) => {
                            if let Some(result) =
                                pipeline::process_chunk(wav_data, &pipeline_config).await
                            {
                                if !result.original.is_empty() {
                                    subtitle.show_bilingual(result.original, result.translated);
                                }
                            }
                        }
                        Err(std::sync::mpsc::RecvTimeoutError::Timeout) => continue,
                        Err(std::sync::mpsc::RecvTimeoutError::Disconnected) => break,
                    }
                }
            });
        });

        write_log_line("[字幕] 翻译管道线程已启动", None);

        Ok(Self {
            stop_flag,
            subtitle_window,
            capture_handle: Some(capture_handle),
            chunker_handle: Some(chunker_handle),
            pipeline_handle: Some(pipeline_handle),
        })
    }

    pub fn update_subtitle_config(&self, config: &ConfigManager) {
        self.subtitle_window.set_original_font_size(config.interpreter_original_font_size());
        self.subtitle_window.set_original_color(config.interpreter_original_color());
        self.subtitle_window.set_translated_font_size(config.interpreter_translated_font_size());
        self.subtitle_window.set_translated_color(config.interpreter_translated_color());
        self.subtitle_window.set_click_through(config.interpreter_subtitle_click_through());
        self.subtitle_window.set_opacity(config.interpreter_subtitle_opacity());
        self.subtitle_window.set_font_size(config.interpreter_subtitle_font_size());
        self.subtitle_window.set_position(config.interpreter_subtitle_position());
    }

    pub fn stop(&mut self) {
        write_log_line("[字幕] 正在停止实时字幕引擎...", None);
        self.stop_flag.store(true, Ordering::Relaxed);
        self.subtitle_window.hide();
        self.subtitle_window.shutdown();
        pipeline::reset_last_transcription();

        if let Some(handle) = self.capture_handle.take() {
            let _ = handle.join();
        }
        if let Some(handle) = self.chunker_handle.take() {
            let _ = handle.join();
        }
        if let Some(handle) = self.pipeline_handle.take() {
            let _ = handle.join();
        }
    }
}
