use crate::config::ConfigManager;
use crate::utils::logger::{write_log, LogLevel};

use std::sync::Mutex;

// 上下文翻译记忆：保留最近 5 句，超过 120s 的自动过期
static TRANSLATION_CONTEXT: once_cell::sync::Lazy<Mutex<Vec<(String, String, std::time::Instant)>>> =
    once_cell::sync::Lazy::new(|| Mutex::new(Vec::new()));

pub fn reset_translation_context() {
    TRANSLATION_CONTEXT.lock().unwrap().clear();
}

pub fn reset_last_transcription() {
    reset_translation_context();
}

#[derive(Debug, Clone)]
pub struct SubtitleResult {
    pub original: String,
    pub translated: Option<String>,
}

pub async fn process_chunk(wav_data: Vec<u8>, config: &ConfigManager) -> Option<SubtitleResult> {
    let raw_text = transcribe(&wav_data, config).await?;
    let raw_trimmed = raw_text.trim();

    write_log(LogLevel::INFO, &format!("[字幕] 转写原文: {}", raw_trimmed), None);

    // 过滤掉幻觉词和无意义输出
    let text = filter_hallucination(raw_trimmed)?;

    if !config.interpreter_use_translation() {
        return Some(SubtitleResult {
            original: text,
            translated: None,
        });
    }

    let source = config.interpreter_source_language();
    let target = config.interpreter_target_language();

    // 源语言和目标语言相同时不翻译
    if source != "auto" && source == target {
        return Some(SubtitleResult {
            original: text,
            translated: None,
        });
    }

    let ctx: Vec<(String, String)> = if config.interpreter_translation_context() {
        let now = std::time::Instant::now();
        TRANSLATION_CONTEXT
            .lock()
            .unwrap()
            .iter()
            .filter(|(_, _, t)| now.duration_since(*t).as_secs() < 120)
            .map(|(o, t, _)| (o.clone(), t.clone()))
            .collect()
    } else {
        Vec::new()
    };

    match translate(&text, &source, &target, config, &ctx).await {
        Ok(translated) => {
            write_log(LogLevel::INFO, &format!("[字幕] 翻译结果: {}", translated.trim()), None);
            // 保存到上下文
            {
                let mut ctx_lock = TRANSLATION_CONTEXT.lock().unwrap();
                let now = std::time::Instant::now();
                ctx_lock.retain(|(_, _, t)| now.duration_since(*t).as_secs() < 120);
                ctx_lock.push((text.clone(), translated.clone(), now));
                if ctx_lock.len() > 5 {
                    ctx_lock.remove(0);
                }
            }
            Some(SubtitleResult {
                original: text,
                translated: Some(translated),
            })
        }
        Err(e) => {
            write_log(LogLevel::WARN, &format!("[字幕] 翻译失败，显示原文: {}", e), None);
            Some(SubtitleResult {
                original: text,
                translated: None,
            })
        }
    }
}

/// 过滤 Whisper 常见幻觉词。返回 None 表示整条丢弃。
fn filter_hallucination(text: &str) -> Option<String> {
    // 去掉首尾空白和常见无意义标点
    let cleaned = text.trim().trim_matches(|c| c == '.' || c == ',' || c == ' ');

    if cleaned.is_empty() {
        return None;
    }

    // 有效字符（非标点、非空白）少于 2 个，丢弃
    let meaningful: usize = cleaned
        .chars()
        .filter(|c| c.is_alphanumeric() || is_cjk(*c))
        .count();
    if meaningful < 2 {
        return None;
    }

    // Whisper 高频幻觉词列表（不区分大小写）
    let lower = cleaned.to_lowercase();
    let hallucinations = [
        "you", "thank you", "thanks", "thank you.", "thanks.",
        "thank you so much", "thanks for watching", "please subscribe",
        "bye", "bye bye", "bye.", "okay", "ok",
        "hmm", "hm", "uh", "um", "ah", "oh",
        "...", "..", ".", "!", "?",
        "subtitles by", "subtitled by", "transcript",
        "♪", "♫", "[music]", "[applause]", "[laughter]",
        // 中文常见幻觉
        "谢谢", "谢谢你", "谢谢大家", "再见", "好的", "嗯",
    ];

    for &h in &hallucinations {
        if lower == h {
            write_log(
                LogLevel::DEBUG,
                &format!("[字幕] 过滤幻觉词: {:?}", cleaned),
                None,
            );
            return None;
        }
    }

    Some(cleaned.to_string())
}

fn is_cjk(c: char) -> bool {
    matches!(c as u32,
        0x4E00..=0x9FFF   // 基本汉字
        | 0x3040..=0x309F // 平假名
        | 0x30A0..=0x30FF // 片假名
        | 0xAC00..=0xD7AF // 韩文
    )
}

async fn transcribe(wav_data: &[u8], config: &ConfigManager) -> Option<String> {
    if config.interpreter_use_local_whisper() {
        let wav = wav_data.to_vec();
        let cfg = config.clone();
        match tokio::task::spawn_blocking(move || {
            crate::whisper_local::LocalWhisper::transcribe_sync(&wav, &cfg)
        })
        .await
        {
            Ok(Ok(text)) => Some(text),
            Ok(Err(e)) => {
                write_log(LogLevel::ERROR, &format!("[字幕] 本地 Whisper 失败: {}", e), None);
                None
            }
            Err(e) => {
                write_log(LogLevel::ERROR, &format!("[字幕] 本地 Whisper 任务异常: {}", e), None);
                None
            }
        }
    } else {
        let api_key = {
            let k = config.interpreter_api_key();
            if k.is_empty() { config.get_groq_api_key() } else { k }
        };
        if api_key.is_empty() {
            write_log(LogLevel::ERROR, "[字幕] 转写 API Key 未配置", None);
            return None;
        }

        let api_url = config.interpreter_api_url();
        let model = config.interpreter_model_name();
        let source = config.interpreter_source_language();

        let mut form = reqwest::multipart::Form::new()
            .text("model", model)
            .text("response_format", "json")
            .part(
                "file",
                reqwest::multipart::Part::bytes(wav_data.to_vec())
                    .file_name("audio.wav")
                    .mime_str("audio/wav")
                    .unwrap(),
            );

        // 已知源语言时传给 API，省去自动检测的开销和短片段误识别
        if source != "auto" {
            form = form.text("language", source);
        }

        let resp = crate::api::client::HTTP_CLIENT
            .post(&api_url)
            .header("Authorization", format!("Bearer {}", api_key))
            .multipart(form)
            .send()
            .await;

        match resp {
            Ok(r) if r.status().is_success() => {
                match r.json::<crate::api::client::ApiResponse>().await {
                    Ok(result) => Some(result.text),
                    Err(e) => {
                        write_log(LogLevel::ERROR, &format!("[字幕] 解析转写响应失败: {}", e), None);
                        None
                    }
                }
            }
            Ok(r) => {
                let status = r.status();
                let body = r.text().await.unwrap_or_default();
                write_log(LogLevel::ERROR, &format!("[字幕] 转写 API 错误 {}: {}", status, body), None);
                None
            }
            Err(e) => {
                write_log(LogLevel::ERROR, &format!("[字幕] 转写请求失败: {}", e), None);
                None
            }
        }
    }
}

fn lang_display(code: &str) -> &str {
    match code {
        "zh" => "简体中文",
        "en" => "English",
        "ja" => "日本語",
        "ko" => "한국어",
        "fr" => "Français",
        "de" => "Deutsch",
        "es" => "Español",
        "ru" => "Русский",
        "ar" => "العربية",
        "auto" | _ => "the source language",
    }
}

async fn translate(
    text: &str,
    source_lang: &str,
    target_lang: &str,
    config: &ConfigManager,
    context: &[(String, String)],
) -> Result<String, String> {
    let api_key = {
        let k = config.interpreter_translation_api_key();
        if k.is_empty() { config.get_groq_api_key() } else { k }
    };
    if api_key.is_empty() {
        return Err("翻译 API Key 未配置".to_string());
    }

    let api_url = config.interpreter_translation_api_url();
    let model = config.interpreter_translation_model();
    let source_desc = lang_display(source_lang);
    let target_desc = lang_display(target_lang);

    let system_prompt = format!(
        "You are a professional real-time interpreter from {} to {}.\n\
         Rules:\n\
         - Output ONLY the translated text, nothing else\n\
         - No explanations, no notes, no parentheses\n\
         - Keep proper nouns, names, and brands untranslated\n\
         - Match the register: casual speech stays casual, formal stays formal\n\
         - If the input is already in {}, output it as-is",
        source_desc, target_desc, target_desc
    );

    let mut messages = vec![
        serde_json::json!({"role": "system", "content": system_prompt}),
    ];
    // 注入上下文（Few-shot），帮助模型保持术语一致性
    for (orig, trans) in context {
        messages.push(serde_json::json!({"role": "user", "content": orig}));
        messages.push(serde_json::json!({"role": "assistant", "content": trans}));
    }
    messages.push(serde_json::json!({"role": "user", "content": text}));

    let resp = crate::api::client::HTTP_CLIENT
        .post(&api_url)
        .header("Authorization", format!("Bearer {}", api_key))
        .header("Content-Type", "application/json")
        .json(&serde_json::json!({
            "model": model,
            "messages": messages,
            "temperature": 0.2,
            "max_tokens": 512,
        }))
        .send()
        .await
        .map_err(|e| format!("翻译请求失败: {}", e))?;

    if !resp.status().is_success() {
        let status = resp.status();
        let body = resp.text().await.unwrap_or_default();
        return Err(format!("翻译 API 错误 {}: {}", status, body));
    }

    let body: serde_json::Value = resp
        .json()
        .await
        .map_err(|e| format!("解析翻译响应失败: {}", e))?;

    body["choices"][0]["message"]["content"]
        .as_str()
        .map(|s| s.trim().to_string())
        .ok_or_else(|| "翻译响应格式异常".to_string())
}